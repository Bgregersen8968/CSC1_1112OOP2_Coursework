import java.io.*;
import java.util.Scanner;

public class Exercise17_14 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		System.out.print("Enter the input file: ");
		String inputFileName = in.nextLine();

		System.out.print("Enter the output file: ");
		String outputFileName = in.nextLine();

		try (FileInputStream In = new FileInputStream(inputFileName);
				FileOutputStream out = new FileOutputStream(outputFileName)) {

			int byteRead;
			while ((byteRead = In.read()) != -1) {
				byte encryptedByte = (byte) (byteRead + 5);
				out.write(encryptedByte);
			}

			System.out.println("File encrypted");
		} catch (IOException e) {
			System.out.println("Error encrypting file: " + e.getMessage());
		}
	}
}