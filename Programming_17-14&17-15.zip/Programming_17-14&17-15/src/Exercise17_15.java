import java.io.*;
import java.util.Scanner;

public class Exercise17_15 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		System.out.print("Enter the encrypted input file: ");
		String inputFileName = in.nextLine();

		System.out.print("Enter the output file: ");
		String outputFileName = in.nextLine();

		try (FileInputStream In = new FileInputStream(inputFileName);
				FileOutputStream out = new FileOutputStream(outputFileName)) {

			int byteRead;
			while ((byteRead = In.read()) != -1) {
				byte decryptedByte = (byte) (byteRead - 5);
				out.write(decryptedByte);
			}

			System.out.println("File decrypted");
		} catch (IOException e) {
			System.out.println("Error decrypting file: " + e.getMessage());
		}
	}
}