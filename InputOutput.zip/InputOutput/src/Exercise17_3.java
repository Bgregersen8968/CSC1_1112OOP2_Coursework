import java.io.*;
import java.util.Random;
import java.util.Scanner;

public class Exercise17_3
 
{

  public static void main(String[] args) throws IOException {
    DataFile();
    int sum = readDataFile();
    System.out.println("The total of all 100 numbers = " + sum);
  }

  public static void DataFile() throws IOException {
    File file = new File("Exercise17_3.dat");
    try (DataOutputStream output = new DataOutputStream(new FileOutputStream(file))) {
      Random random = new Random();
      for (int i = 0; i < 100; i++) {
        output.writeInt(random.nextInt(1000));
      }
    }
  }

  public static int readDataFile() throws IOException {
    File file = new File("Exercise17_3.dat");
    int sum = 0;
    try (DataInputStream input = new DataInputStream(new FileInputStream(file))) {
      while (true) {
        sum += input.readInt();
      }
    } catch (EOFException e) {
      // Reached end of file, no more to read
    }
    return sum;
  }
}