import java.io.*;
import java.util.Random;
import java.util.Scanner;

public class Exercise17_01 {

  public static void main(String[] args)
 
throws IOException {
    Random random = new Random();
    try (PrintWriter writer = new PrintWriter(new FileWriter("Exercise17_01.txt", true))) {
      for (int i = 0; i < 100; i++) {
    	  //int randomNumber = random.nextInt(1000);
        writer.print(random.nextInt(10000) + " ");
      }
    writer.close();
    Scanner input = new Scanner(new File("Exercise17_01.txt"));
    System.out.println(input.nextLine());
  }
}
  }